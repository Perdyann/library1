
<div id="hotel">
    <div class="menu">
        <ul>
            <li>
                <a href="#"><span class="img"><img src="icons/b_tran.png"width='20px'  height='18px' style=" padding-top:3px;"></span>&nbsp;Login<span class="arrow"></span></a>
                
                <ul>
                    <li><div id="id" style="cursor:pointer; height:30px; background:#FFF; width:100px;">&nbsp;Admin</div></li>
                  
                </ul>
    </div>
    <div id='inlineBox' class='popup_block'>
			<div id='inlineBoxAjax'></div>
		</div>
   